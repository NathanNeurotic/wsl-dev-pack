#!/usr/bin/env bash
set -euo pipefail

git config --global --add safe.directory "$(pwd)" || true

echo "Devcontainer bootstrap complete."
